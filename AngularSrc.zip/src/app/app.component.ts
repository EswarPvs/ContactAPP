import { Component } from '@angular/core';
import { Contact } from './Contact';
import { ContactService } from './contact.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Phone';
  data: any;
  constructor(private service:ContactService){
    
  }
  ngOnInit(){
    this.service.getContacts().subscribe(data =>{
      this.data=data;
  })
}
deleteUser(firstName:String){
  this.service.deleteContact(firstName).subscribe();
  this.ngOnInit();
}
}
