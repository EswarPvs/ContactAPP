import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-edit-contact',
  templateUrl: './edit-contact.component.html',
  styleUrls: ['./edit-contact.component.css']
})
export class EditContactComponent implements OnInit {
  con : Contact = new Contact();
  

  constructor(private service:ContactService) { }

  ngOnInit(): void {
  }
  updateContacts() {
    this.service.updateContact(this.con).subscribe(data => {
     
    })
}
}
