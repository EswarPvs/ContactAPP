import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  conn: Contact = new Contact();
  constructor(private service :ContactService) { 
    this.conn.firstName = 'Mom';
    this.conn.lastName="252220";
    this.conn.number="12345678";
  }

  ngOnInit(): void {
  }
  addContacts(){
    alert(JSON.stringify(this.conn));
    this.service.addContact(this.conn).subscribe(data =>{ 
      alert(JSON.stringify(data))
      alert(data);
      
      if(data != null) {
        alert("Added Successfully");

      }
    
    
    
    });
  }

}
