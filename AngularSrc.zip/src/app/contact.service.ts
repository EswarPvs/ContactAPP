import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Contact } from './Contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  
  constructor(private http: HttpClient ) { }
  getContacts(){
    let url = 'http://localhost:8080/ContactApp/rest/Contactservice/allcontacts';
    return this.http.get(url);
  }
  addContact(contact:Contact){
    let url = 'http://localhost:8080/ContactApp/rest/Contactservice/add';
    return this.http.post(url,contact);
  }
  deleteContact(firstName:String)
  {
    let url = 'http://localhost:8080/ContactApp/rest/Contactservice/' +firstName;
    return this.http.delete(url);
  }
  updateContact(contact: Contact){
    let url = 'http://localhost:8080/ContactApp/rest/Contactservice/update';
    return this.http.put(url, contact);

  }
  viewContact(firstName:String)
  {
    let url='http://localhost:8080/ContactApp/rest/Contactservice/'+firstName;
    return this.http.get(url);
  }
  
}
