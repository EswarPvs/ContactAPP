import { Component, OnInit } from '@angular/core';
import { Contact } from '../Contact';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-view-contact',
  templateUrl: './view-contact.component.html',
  styleUrls: ['./view-contact.component.css']
})
export class ViewContactComponent implements OnInit {
  firstName: string;
  Contact: any;


  constructor(private service:ContactService) { }

  ngOnInit(): void {}
  viewContacts() {
    this.service.viewContact(this.firstName).subscribe(data => {
      this.Contact =data;
      console.log(data);
      
   })
  }
}