export class Contact{
    firstName: String;
    lastName: String;
    number:String;
 }