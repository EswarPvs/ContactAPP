package com.pojo;
import java.util.List;
import javax.ws.rs.PathParam;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;

import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
 
@Path("/Contactservice")
public class ContactService {
	@GET
	@Path("/allcontacts")
	@Produces(MediaType.APPLICATION_JSON)
public List<Contact> getFirstName() {
		 List<Contact> listOfContacts = ContactDao.getAllContacts();
	        return listOfContacts;
	}
	        @GET
	        @Path("/{FirstName}")
	        @Produces(MediaType.APPLICATION_JSON)
	        public List<Contact> getContact(@PathParam("FirstName") String FirstName) {
	            return ContactDao.getContact(FirstName);
	        }
	     
	        @POST
	        @Path("/add")
	        @Consumes(MediaType.APPLICATION_JSON)
	        public Contact addContact(Contact con) {
	            return ContactDao.addContact(con);
	        }
	        @PUT
	        @Path("/update")
	        @Produces( MediaType.APPLICATION_JSON)
	        public Contact updateContact(Contact con) {
	            return ContactDao.updateContact(con);
	        }
	        @DELETE
	        @Path("/{FirstName}")
	        @Produces(MediaType.APPLICATION_JSON)
	        public void deleteEmployee(@PathParam("FirstName") String FirstName) {
	            ContactDao.deleteEmployee(FirstName);
	        }
	
}

