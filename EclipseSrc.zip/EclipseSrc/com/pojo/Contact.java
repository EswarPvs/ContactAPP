package com.pojo;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "contact" )
public class Contact {


 
    private String FirstName;
    private String LastName;
    private String number;
 
   
    public Contact() {
 
    }
 
    public Contact(String firstName, String lastName, String number) {
        this.FirstName = firstName;
        this.LastName = lastName;
        this.number = number;
    }

	public String getFirstName() {
		return FirstName;
	}
	@XmlElement
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getLastName() {
		return LastName;
	}
	@XmlElement
	public void setLastName(String lastName) {
		LastName = lastName;
	}

	public String getNumber() {
		return number;
	}
	@XmlElement
	public void setNumber(String number) {
		this.number = number;
	}
 
    
 
}