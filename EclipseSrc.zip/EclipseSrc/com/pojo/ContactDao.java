package com.pojo;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
 

public class ContactDao {
	 private static final Map<String, Contact> conMap = new HashMap<String, Contact>();
	 
	    static {
	        initCons();
	    }
	 
	    private static void initCons() {
	        Contact con1 = new Contact("Bill", "Smith", "94-765-7642");
	        Contact con2 = new Contact("Fred", "allen", "210-657-9886");
	        Contact con3 = new Contact("Kobe", "Bryant","211-643-7664");
	 
	        conMap.put(con1.getFirstName(), con1);
	        conMap.put(con2.getFirstName(), con2);
	        conMap.put(con3.getFirstName(), con3);
	        
	        
	    }
	 
	    public static List<Contact> getContact(String FirstName) {
	    	List<Contact> list=new ArrayList<Contact>();
	    	list.add(conMap.get(FirstName));
	    	return list;
	    }
	    
	    public static Contact addContact(Contact con) {
	        conMap.put(con.getFirstName(), con);
	        return con;
	    }
	 
	    public static Contact updateContact(Contact con) {
	        conMap.put(con.getFirstName(), con);
	        return con;
	    }
	 
	    public static void deleteEmployee(String FirstName) {
	        conMap.remove(FirstName);
	    }
	 
	    public static List<Contact> getAllContacts() {
	        Collection<Contact> c = conMap.values();
	        List<Contact> list = new ArrayList<Contact>();
	        list.addAll(c);
	        return list;
	    }
	     
	    List<Contact> list;
	 
	}


